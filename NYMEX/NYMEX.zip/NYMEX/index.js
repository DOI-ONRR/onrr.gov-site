var e=({filter:e,action:t})=>{e("items.create",(()=>{console.log("Creating Item!")})),t("items.create",(()=>{console.log("Item created!")}))};export{e as default};
